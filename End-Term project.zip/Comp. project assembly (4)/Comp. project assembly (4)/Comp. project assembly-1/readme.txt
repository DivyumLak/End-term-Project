# Writing read me

**Version 1.0.0**

Project made on Sports shopping website for Formative assesment-4.


## License & Copyright

©Team tech connect

## Browsing through the website

After Clicking on "Open.hmtl" a user will see a webpage where name of our website will be present.
Once user clicks on "FITNESS HUB", a login page will be shown where user has to enter its login details, by default username is "user@gmail.com"
and password is "123456", once user clicks on "Login",
 Mainpage of website will be displayed. User can browse through various products.

 After finding the suitable product for themselves user has to click on "Buy it here", and then user will be redirected to the payment gateway,
 where after entering all the required details and clicking on "Continue to checkout", User will get dialogbox where OTP is to be entered for compleation 
 of payment, by default OTP that is supposed to enter is "1111". 

 Depending upon wheather the entered OTP is right or not user will be informed.

 ## Happy shopping## 